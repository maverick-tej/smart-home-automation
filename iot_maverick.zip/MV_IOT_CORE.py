from flask import Flask, request, render_template, jsonify
import time
import RPi.GPIO as PINS

# Define pins
R1 = 17
R2 = 27
R3 = 22
R4 = 10
R5 = 9
R6 = 11
R7 = 5
R8 = 6
R9 = 13
R10 = 19
AC = 26  
LED_STATUS = 21

# Setup GPIO
PINS.setwarnings(False)
PINS.setmode(PINS.BCM)
PINS.setup(R1, PINS.OUT)
PINS.setup(R2, PINS.OUT)
PINS.setup(R3, PINS.OUT)
PINS.setup(R4, PINS.OUT)
PINS.setup(R5, PINS.OUT)
PINS.setup(R6, PINS.OUT)
PINS.setup(R7, PINS.OUT)
PINS.setup(R8, PINS.OUT)
PINS.setup(R9, PINS.OUT)
PINS.setup(R10, PINS.OUT)
PINS.setup(AC, PINS.OUT)
PINS.setup(LED_STATUS, PINS.OUT)

PINS.output(LED_STATUS, True)

# Define global states
login_access = False
RSTATE1 = RSTATE2 = RSTATE3 = RSTATE4 = RSTATE5 = False
RSTATE6 = RSTATE7 = RSTATE8 = RSTATE9 = RSTATE10 = False
AC_STATE = False

iotpage = Flask(__name__)

class RelayApi:
    @staticmethod
    def request_handler(relay_id):
        global RSTATE1, RSTATE2, RSTATE3, RSTATE4, RSTATE5
        global RSTATE6, RSTATE7, RSTATE8, RSTATE9, RSTATE10, AC_STATE
        if relay_id == "R1":
            RSTATE1 = not RSTATE1
            print("R1:", RSTATE1)
            PINS.output(R1, RSTATE1)
        elif relay_id == "R2":
            RSTATE2 = not RSTATE2
            print("R2:", RSTATE2)
            PINS.output(R2, RSTATE2)
        elif relay_id == "R3":
            RSTATE3 = not RSTATE3
            print("R3:", RSTATE3)
            PINS.output(R3, RSTATE3)
        elif relay_id == "R4":
            RSTATE4 = not RSTATE4
            print("R4:", RSTATE4)
            PINS.output(R4, RSTATE4)
        elif relay_id == "R5":
            RSTATE5 = not RSTATE5
            print("R5:", RSTATE5)
            PINS.output(R5, RSTATE5)
        elif relay_id == "R6":
            RSTATE6 = not RSTATE6
            print("R6:", RSTATE6)
            PINS.output(R6, RSTATE6)
        elif relay_id == "R7":
            RSTATE7 = not RSTATE7
            print("R7:", RSTATE7)
            PINS.output(R7, RSTATE7)
        elif relay_id == "R8":
            RSTATE8 = not RSTATE8
            print("R8:", RSTATE8)
            PINS.output(R8, RSTATE8)
        elif relay_id == "R9":
            RSTATE9 = not RSTATE9
            print("R9:", RSTATE9)
            PINS.output(R9, RSTATE9)
        elif relay_id == "R10":
            RSTATE10 = not RSTATE10
            print("R10:", RSTATE10)
            PINS.output(R10, RSTATE10)
        elif relay_id == "acbutton":
            AC_STATE = not AC_STATE
            print("AC:", AC_STATE)
            PINS.output(AC, AC_STATE)

class GateKeeper:
    @staticmethod
    def login():
        global login_access
        Maverick_id = request.form["maverick_id"]
        Passcode = request.form["password"]
        print(Maverick_id, Passcode)
        if Maverick_id == "maverick verse" and Passcode == "maverick verse":
            relay_data = {
                "R1": "Fan one",
                "R2": "Fan two",
                "R3": "Fan three",  
                "R4": "Fan four",
                "R5": "Fan five",
                "R6": "Light one",
                "R7": "Light two",
                "R8": "Light three",
                "R9": "Light four",
                "R10": "Light five"
            }    
            login_access = True 
            return render_template("interface.html", relay=relay_data)
        else:
            login_access = False
            return "Denied by maker" 

@iotpage.route('/')
def user_interface():
    return render_template("gate.html")

@iotpage.route('/login')
def login():
    return render_template('login.html')

@iotpage.route('/login_process', methods=['POST'])
def login_verify():
    return GateKeeper.login()

@iotpage.route('/hardware_api')
def hardware_api():
    relay_id = request.args.get('relay_id')
    RelayApi.request_handler(relay_id)
    return "OK"

@iotpage.route('/hardware_update')
def hardware_update():
    global login_access, RSTATE1, RSTATE2, RSTATE3, RSTATE4, RSTATE5
    global RSTATE6, RSTATE7, RSTATE8, RSTATE9, RSTATE10, AC_STATE

    relay_states = {
        "RSTATE1": RSTATE1,
        "RSTATE2": RSTATE2,
        "RSTATE3": RSTATE3,
        "RSTATE4": RSTATE4,
        "RSTATE5": RSTATE5,
        "RSTATE6": RSTATE6,
        "RSTATE7": RSTATE7,
        "RSTATE8": RSTATE8,
        "RSTATE9": RSTATE9,
        "RSTATE10": RSTATE10,
        "AC_STATE": AC_STATE,
        "login": login_access
    }

    return jsonify(relay_states)

if __name__ == '__main__':
    try:
        iotpage.run(host='0.0.0.0', port=5000, debug=True)
    finally:
        PINS.cleanup()  # Clean up GPIO on exit
