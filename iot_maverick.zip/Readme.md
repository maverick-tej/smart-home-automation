IoT-Based Home Automation System

This project implements an IoT-based home automation system using Flask and Raspberry Pi. It allows users to control multiple relays (e.g., lights, fans, and an AC) via a web interface. The system also provides real-time updates on hardware states.
Features

    Control up to 10 relays (R1–R10) and an AC through a web interface.
    User authentication for secure access.
    Real-time hardware state updates.
    Designed for Raspberry Pi GPIO control.

Technologies Used

    Python: Flask framework for the web interface and API.
    Hardware: Raspberry Pi, GPIO pins, relays.
    HTML: Templates for the web interface.

Hardware Requirements

    Raspberry Pi (any model with GPIO support).
    10-channel relay module.
    AC appliances like lights and fans.
    Jumper wires for connections.
    Power supply for the Raspberry Pi and relays.

Software Requirements

    Python 3.x
    Flask
    RPi.GPIO library (for GPIO pin control)

Circuit Diagram

Include a diagram showing the connections between:

    Raspberry Pi GPIO pins.
    Relays and appliances.

Setup Instructions

    Clone the Repository:

git clone https://github.com/your-username/iot-home-automation.git
cd iot-home-automation

Install Dependencies:

pip install flask RPi.GPIO

Connect Hardware:

    Follow the provided circuit diagram to connect relays and appliances to the Raspberry Pi GPIO pins.

Run the Application:

    python app.py

        Access the web interface at http://<raspberry-pi-ip>:5000/.

Usage

    Open the login page: http://<raspberry-pi-ip>:5000/login.
    Enter the default credentials:
        Username: maverick verse
        Password: maverick verse
    Use the interface to toggle relays (e.g., lights, fans, AC).
    Access hardware state updates via the /hardware_update endpoint.

API Endpoints

    /: Displays the login page.
    /login_process: Handles user authentication.
    /hardware_api: Accepts relay toggle requests via relay_id.
    /hardware_update: Returns the current state of all relays and login status.

Customization

    Modify GPIO pin assignments in the code (R1–R10, AC, LED_STATUS).
    Add or remove relay controls in the RelayApi class.

Contributing

Feel free to submit issues or pull requests to enhance the project.
License

This project is licensed under the MIT License. See the LICENSE file for details.
Acknowledgments

Special thanks to the Raspberry Pi and Flask communities for their valuable resources and guidance.
